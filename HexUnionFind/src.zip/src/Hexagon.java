public class Hexagon {
    int element;
    boolean isBlue;

    public Hexagon(int el, boolean blue){
        element = el;
        isBlue = blue;
    }
}
